# -*- coding: utf-8 -*-
# try something like
def index():
    h = CAT('Advertisment tools')
    return dict(h=h)
